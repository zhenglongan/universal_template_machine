#ifndef MOTOR_H
#define MOTOR_H

#define MotorFatherVersion      01
#define MotorChildVersion       1
#define MotorSVNVersion         54

extern void init_motor( void );
extern void motor_control( void );
extern void motor_start( void );
extern void MotorPreInit( void );
#endif
//--------------------------------------------------------------------------------------
